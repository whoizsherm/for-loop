#include <iostream>

using namespace std;

int main(){

int j = 10;
int n = 0;
int k = 20;
int d = 5;
  while (j <= 1000){
    cout << j << endl;
    j += 10;
  }

while (n < 18){

cout << "David :P " << endl;
  n++;
  
}


  while (k >= 1){
    cout << k << endl;
    k --; 
  }


  while (d <= 50){
    cout << d << endl;
    d += 5;
  }



  return 0;
}