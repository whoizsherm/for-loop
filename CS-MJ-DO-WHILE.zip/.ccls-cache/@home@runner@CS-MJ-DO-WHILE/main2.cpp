#include <iostream>

using namespace std;

int main2(){

int j = 10;

  while (j <= 1000){
    cout << j << endl;
    j += 10;
  }







    
  return 0;
}









